from django.shortcuts import render

def home(request):
    return render(request, 'home.html')

def films(request):
    movies = [
        {'title': 'Inception', 'imdb': 8.5},
        {'title': 'Joker', 'imdb': 7.5},
        {'title': 'The Dark Knight', 'imdb': 9.0},
        {'title': 'Interstellar', 'imdb': 8.6},
        {'title': 'Venom', 'imdb': 6.7},
    ]
    context = {'movies': movies}
    return render(request, 'films.html', context)
